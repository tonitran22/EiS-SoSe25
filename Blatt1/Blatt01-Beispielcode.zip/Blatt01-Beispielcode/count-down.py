n = 10
for i in range (n,0,-1):
    print(i)
    if i == 8:
        print("ignition sequence start")

print("liftoff!")
